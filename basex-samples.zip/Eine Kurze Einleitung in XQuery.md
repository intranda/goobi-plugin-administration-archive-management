# Eine Kurze Einleitung in XQuery


## Abhängigkeit
1. BaseX (Version = 10.4)
2. Java


## Vorbereitung
1. Die `BaseX104.zip` aus `https://basex.org/download/` herunterladen.
2. Die Verfügbarkeit von java überprüfen mittels `java --version`. Java erneut installieren falls nötig.
3. Die `BaseX104.zip` entpacken.
4. Den Pfad zu `BaseX.jar` ausfinden und den folgenden Kommando ausführen um den GUI zu starten:
```bash
  java -jar Pfad/zu/BaseX.jar
```


## Nützliche Settings des GUIs
### [1] Neue Datenbank anlegen
1. `Datenbank -> Neu...` anklicken oder den Shortcut `Strg + N` drücken.
2. In dem `Datenbank-Optionen` Wizard unter `Allgemein` die XML Datei für die Initialisierung der Datenbank auswählen und einen Namen für die Datenbank eingeben.


### [2] Datenbanken öffnen und verwalten
1. `Datenbank -> Öffnen und verwalten...` anklicken oder den Shortcut `Strg + M` drücken.
2. Die gezielte Datenbank auswählen und einen Button von rechts unten anklicken.


### [3] Aus- und Entkommentieren von Codes
1. Den Zeiger zu der Zeile bewegen oder einen Block von Codes auswählen.
2. Den Shortcut `Strg + K` drücken.


### [4] Einrücken von Ergebnissen
1. Im `Editor` Viewers Menu (links oben) den dritten Button `Ergebnis einrücken` von rechts anklicken,
2. Oder den Shortcut `Strg + Umschalt + I` drücken.


## Usecases
Es wird in den folgenden Usecases vorausgesetzt, dass eine Datenbank namens `EAD_Koch_Fotosammlung` basierend auf der `EAD_Koch_Fotosammlung.XML` erstellt ist.


### [0] Namespace und andere Settings
#### 1. Namespace

```bash
# There are two ways to declare a namespace:
# 1. Declare a default namespace, which is what we will be using.
declare default element namespace "urn:isbn:1-931666-22-9";

# 2. Declare a namespace and create a binding to it.
# In this way, we have to specify the binding's name every time we use the namespace.
declare namespace c = "urn:isbn:1-931666-22-9";
```

### [1] Basis
#### 1. XQuery Basis

```bash
# 1. Comments are to be surrounded by (: and :)
(: This is a comment in Xquery :)

# 2. Create bindings:
let $x := doc("something.xml")

# 3. Iterate over a list:
for $node in $nodes
return $node

# 4. Strings can be enclosed using "" or '', there is no difference.
```


#### 2. Knoten via ID finden

```bash
let $firstClassNode := fn:element-with-id("A91x59286248683929420181205140345809A91x69955980777740420181205140002806")
return $firstClassNode
```


#### 3. Neue Knoten hinzufügen

```bash
# 0. Prepare some nodes for later use:
let $firstClassNode := fn:element-with-id("A91x59286248683929420181205140345809A91x69955980777740420181205140002806")
let $secondClassNode := fn:element-with-id("A91x59286248683929420181205140345809A91x14008545875549320181205140002806")
let $fileNode := fn:element-with-id("A91x59286248683929420181205140345809")

# 1. Prepare the node that is to be inserted:
# 1.1. This can be done manually as following:
let $newNode := (<newNode>something</newNode>)
# 1.2. OR it can be any existing node in the tree:
let $newNode2 := fn:element-with-id("...")

# 2. Choose the insertion way.
# 2.1. According to the implementation of BaseX, the node will be appended to the end of the list if not specified.
#  |   The following line will insert the $newNode into the end of $fileNode's children list, given BaseX is in use.
return insert node $newNode into $fileNode

# 2.2. The default setting varies among implementations, so it could be a good idea to specify the location for insertion.
#  |   The following line will insert the $newNode into the end of $fileNode's children list with no doubt.
return insert node $newNode as last into $fileNode

# 2.3. The following line will insert the $newNode into the beginning of $fileNode's children list with no doubt.
return insert node $newNode as first into $fileNode

# 2.4. One can also insert a node to a relative location to some other nodes.
#  |   The following line will insert the $newNode before the $firstClassNode
return insert node $newNode before $firstClassNode

# 2.5. The following line will insert the $newNode after the $secondClassNode
return insert node $newNode after $secondClassNode
```


#### 4. Knoten nach Namen ausfiltern

```bash
# Get the list of elements named "newNode":
let $newNodes := //newNode

# Then we can get a peek of them using:
for $node in $newNodes
return $node
```


#### 5. Werte von Knoten ändern

```bash
# Change the value of all "newNode"s to "something else":
for $node in //newNode
return replace value of node $node with "something else"
```


#### 6. Knoten umbenennen

```bash
# Rename all "newNode"s to "oldNode":
for $node in //newNode
return rename node $node as "oldNode"
```


#### 7. Knoten durch einen anderen ersetzen

```bash
# Prepare a new node and replace all oldNodes with it:
let $newNode := (<newNode>SOMETHING_BIG</newNode>)

for $node in //oldNode
return replace node $node with $newNode  
```


#### 8. Knoten entfernen

```bash
# Delete all "newNode"s:
return delete node //newNode
```


#### 9. Elternknoten eines Knoten finden

```bash
# Get the parent of $fileNode:
# 1. Either use ..:
return $fileNode/..

# 2. Or use the parent axis:
return $fileNode/parent::*
```


#### 10. Namen und Werte eines Knoten finden

```bash
# Get the name of $fileNode:
return name($fileNode)

# Get the string value of $fileNode
return string($fileNode)

# Get the typed value of $fileNode
return data($fileNode)

# Differences between string() and data():
# 1. string() will always return a string.
# 2. data() returns the "typed value", which is usually xs:string,
#    BUT can also be xs:untypedAtomic or any other atomic type.
# 3. Applying data() on a document node will return the string value of the node,
#    BUT its type is xs:untypedAtomic.
# ===============================================================================
# GENERAL RULE:
# if you want a string, use string() not data()
# ===============================================================================
```


#### 11. Knoten nach Positionen ausfiltern

```bash
# Get the list of all the nodes named "did"
let $dids := //did

# 1. Get the first one:
return $dids[1]

# 2. Get the last one:
return $dids[ last()]

# 3. Get all but the first:
return $dids[ position() > 1]

# 4. Get all but the last:
return $dids[ position() < last()]

# 5. Get the one at position 7:
# 5.1. Either use the index directly:
return $dids[7]
# 5.2. Or use the position() method:
return $dids[position() = 7]
```


### [2] Kompliziertere
#### 0. Vorbereitung

```bash
let $firstClassNode := fn:element-with-id("A91x59286248683929420181205140345809A91x69955980777740420181205140002806")
let $secondClassNode := fn-element-with-id("A91x59286248683929420181205140345809A91x14008545875549320181205140002806")
let $fileNode := fn-element-with-id("A91x59286248683929420181205140345809")
```


#### 1. Reihenfolge zweier Geschwister-Knoten wechseln

```bash
# Exchange locations of $firstClassNode and $secondClassNode:
return (
  delete node $firstClassNode,
  insert node $firstClassNode after $secondClassNode
)
```


#### 2. Knoten aus deren Eltern ausnehmen

```bash
# Take the $firstClassNode out of the $fileNode
# and make it the first subnode of $fileNode's parent:
return (
  delete node $firstClassNode,
  insert node $firstClassNode as first into $fileNode/..
)
```


#### 3. Knoten innerhalb einen anderen einpacken

```bash
# Move the $firstClassNode into $fileNode again:
return (
  delete node $firstClassNode,

  # 1. If you have a node as reference, e.g. $secondClassNode, you may use the relative command:
  insert node $firstClassNode before $secondClassNode

  # 2. Otherwise you may also specify the parent node only. Depending on the implementations, the new node
  #  | would be added either from ahead or from behind. In BaseX, the new node would be appended to the tail.
  insert node $firstClassNode into $fileNode  
)
```


#### 4. Knoten via Attribute ausfiltern

```bash
# 1. Get all nodes which have a "level" attribute:
for $node in //node()[fn:exists(@level)]
return $node

# 2. Get all nodes whose "level" is "file":
# 2.1. Either use the bracket:
for $node in //node()[@level = "file"]
return $node
# 2.2. Or use the "where" clause:
for $node in //node()
where $node/@level = "file"
return $node
```


#### 5. Neue Attribute in Knoten hinzufügen

```bash
# 1. Add an attribute "att" valued "7" into the $fileNode:
return insert node attribute {"att"} {"7"} into $fileNode

# 2. Add an attribute "notfile" to all nodes whose "level" are not "file":
for $node in //node()[fn:exists(@level)]
where not($node/@level = "file")
return insert node attribute {"notfile"} {true} into $node
# ATTENTION: the last return command will add empty "notfile" attributes and it is intended so for case 6.
```


#### 6. Werte von Attribute ändern

```bash
# Replace the value of empty "notfile" attributes with "true":
for $node in //@notfile
where string-length($node) = 0
return replace value of node $node with "true"
```


#### 7. Attribute umbenennen

```bash
# Rename the attribute node "notfile" to "nofile":
# 1. Either use the RENAME way:
for $node in //@notfile
return rename node $node as "nofile"

# 2. Or use one of the two listed in case 8.
```


#### 8. Attribut durch einen anderen ersetzen

```bash
# Replace the attribute nodes "nofile" with "notfile"
# 1. Either use the DELETE-INSERT way:
for $node in //@nofile
return (
  delete node $node,
  insert node attribute {"notfile"} {string($node)} into $node/..
)

# 2. OR use the REPLACE way:
for $node in //@nofile
return replace node $node with attribute {"notfile"} {string($node)}
```


#### 9. Attribute entfernen

```bash
# 1. Remove the attribute "notfile" from nodes whose "level" is "class"
for $node in //node()[@level = "class"]
return delete node $node/@notfile

# 2. Remove the attribute "notfile" from all nodes
return delete node //@notfile
```


#### 10. Existenz eines Attributs bestimmen

```bash
# 1. Determine the existence of the attribute "level" of $fileNode, $firstClassNode and $secondClassNode
return (
  fn:exists($fileNode/@level),
  fn:exists($firstClassNode/@level),
  fn:exists($secondClassNode/@level)
)

# 2. Determine the existence of the attribute "id" given "level", and return the
# name of the nodes that do not pass the existence check:
for $node in //@level/..
let $existence := fn:exists($node/@id)
return (
  if ($existence)
  then ()
  else (name($node))
)
```


#### 11. Knoten von derselben Tiefe finden

```bash
# Define the depth of a node as the number of its ancestors.
# 1. Get all depth-10 nodes in the following way:
for $node in //*[count(ancestor::*) = 10]
return $node

# 2. Get all nodes of depth not smaller than 10 whose value does not contain "Papier"
for $node in //*[count(ancestor::*) >= 10]
return (
  if (not(fn:contains($node/text(), "Papier")))
  then ($node)
)
```


#### 12. Kinderknoten von einem gegebenen Knoten finden

```bash
# 1. Get all the children nodes of $secondClassNode:
return $secondClassNode/child::*

# 2. Get the children nodes "did" of the first depth-1 node:
let $node := (//*[count(ancestor::*) = 1])[1]
return $node/child::did
```


#### 13. Beispiele zur Nutzung von XPath Axes

```bash
# 1. Get all the attributes of $firstClassNode:
return $firstClassNode/attribute::*

# 2. Check if $secondClassNode belongs to the following-siblings of $firstClassNode:
return $secondClassNode = $firstClassNode/following-sibling::*

# 3. Check if $firstClassNode is one of the preceding nodes of $secondClassNode with an id:
return $firstClassNode = $secondClassNode/preceding::*[@id]

# 4. Check that the value of ancestor-or-self is exactly one plus the number of ancestors:
return 1 + count($firstClassNode/ancestor::*) = count($firstClassNode/ancestor-or-self::*)

# 5. Get all descendants named "did" of $secondClassNode:
return $secondClassNode/descendant::did

# 6. Get $fileNode's children nodes named "did" which has itself a "unittitle" subnode
return $fileNode/child::did[unittitle]

# 7. Check that all nodes named "c" following $secondClassNode have an "id":
return count($secondClassNode/following::c[not(@id)]) = 0
```


## Bemerkungen
1. XQuery ist eine funktionale Sprache und sie hat viele Merkmale die imperative Sprachen wie Java nicht besitzen oder ganz anders interpretiert haben. Ein Beispiel dafür ist die Nutzung von "Variablen". Es gibt eigentlich in XQuery keine echten Variablen, sondern nur Konstanten, und die Werteanweisung kann mittels `:=` gemacht werden. Das Gleichheitszeichen `=` funktioniert fast genau wie das `==` in Java aber auch nicht ganz. Siehe dazu die nächste Bemerkung:
2. Es gibt zwei verschiedene Gruppen Vergleichssymbolen:
||Wertevergleich|Allgemeiner Vergleich|
|:---:|:----:|:----:|
|equals|`eq`|`=`|
|not equals|`ne`|`!=`|
|less than|`lt`|`<`|
|greater than|`gt`|`>`|
|less than or equal to|`le`|`<=`|
|greater than or equal to|`ge`|`>=`|

  Das Problem ist, dass diese zwei Arten Symbolen nicht überall mit einander ersetzbar sind. Die Symbole der Gruppe `Wertevergleich` vergleicht einzelne Werte, während die der Gruppe `Allgemeiner Vergleich` eher als Existenz Überprüfer funktionieren. Beispielsweise wird der Aufruf `"foo" eq ("foo", "bar")` zu einer Fehlermeldung geführt, aber der Aufruf `"foo" = ("foo", "bar")` wird dagegen zu einem `true`. Tatsächlich gibt es für den zweiten Aufruf eine präzisere aber deswegen auch längere Version:

  ```bash
  some $item1 in "foo", $item2 in ("foo", "bar") satisfies $item1 eq $item2
  ```

3. Namespaces sind wichtig in XQuery. Viele Fehler tauchen auf wegen einem falschen Einsatz von Namespaces. Ein gutes Beispiel dafür wäre der Aufruf `doc("index.html")/html/body/p[@class="example"]`, der gar nichts "matchen" kann. Das Problem liegt daran, dass "index.html" eine XHTML Datei ist und alle XHTML Dateien den defaulten Namespace `http://www.w3.org/1999/xhtml` in ihren top (<html>) Elementen deklariert. Deshalb muss man auch in XQuery diesen Namespace deklarieren, um eine XHTML Datei zu bearbeiten:

  ```bash
  declare namespace x = "http://www.w3.org/1999/xhtml/";
  doc("index.html"/x:html/x:body/x:p[@class="example"])
  ```

4. Wenn Namespaces zur Nutzung gebracht werden, muss man sehr vorsichtig sein. Es gibt zwar eine einfachere Weise einen defaulten Namespace zu deklarieren, unerwartete Problemen mögen auch daraus kommen. Ein Beispiel dafür wäre der folgende Versuch einen Output in Form XHTML zu generieren:

  ```bash
  declare default element namespace "http://www.w3.org/1999/xhtml";
  <html>
    <body>
      {
        for $i in doc("testResult.xml")/tests/test[@status = "failure"]
        order by $i/@name
        return <p>{$i/@name}</p>
      }
    </body>
  </html>
  ```
  Diese Codes funktionieren nicht. Grund dafür ist genau die defaulte Namespace Deklarierung. Der defaulte Namespace wird automatisch an allen Elementen eingesetzt, egal ob sie überhaupt in dem deklariert sind oder nicht. Aber die Input-Datei "testResult.xml" enthält wahrscheinlich nur Elemente aus einem leeren Namespace und der Einsatz von dem defaulten Namespace wird dann alles kaputt machen. Eine Lösung dafür ist folgendes:

  ```bash
  declare namespace x = "http://www.w3.org/1999/xhtml";
  <x:html>
    <x:body>
      {
        for $i in doc("testResult.xml")/tests/test[@status = "failure"]
        order by $i/@name
        return <x:p>{$i/@name}<x:p>
      }
    </x:body>
  </x:html>
  ```
5. Zu beachten ist auch, dass die `doc()` Funktion den `Dokument Knoten` zurückgibt, aber ***NICHT*** den `Top Element Knoten <html>`. Das heißt also, dass man noch den Knoten `<html>` manuell "matchen" muss, wenn man einen absoluten Matching-Pfad benutzen möchte:

   ```bash
   doc("index.html")/html/body
   ```  
6. Ausdruck Vorrang ist ein weiteres wichtiges Thema in XQuery, denn die Nutzung von Klammern ist viel wichtiger für XQuery als für andere Sprachen, um Vorrang zu schaffen. Grund für diesen Unterschied ist genau die Tatsache dass XQuery eine funktionale Sprache ist. Zum Beispiel würden die folgenden Codes nicht mehr richtig laufen, wenn wir die Klammern hinter dem `return` wegnähmen:

  ```bash
  for $i in (reverse(1 to 10)),
      $d in xs:integer(doc("numbers.xml")/numbers/number)
  return ($i + $d)
  ```
7. Ein anderes Beispiel bzgl. der Wichtigkeit vom Vorrang liegt in dem Vergleich der folgenden zwei Aufrufe:
   - `return doc("doc.txt")/doc/p/span[1]` wird für jedes Element aus der Liste erzeugt durch `doc("doc.txt")/doc/p` sein erstes Kindknoten namens `span` zurückgeben.
   - `return (doc("doc.txt")/doc/p/span)[1]` wird hingegen nur das allererste `span` Knoten zurückgeben.
8. Wenn ein Ausdruck innerhalb eines Element-Konstruktors ausgewertet werden sollte, muss man ihn zuerst in geschweifte Klammern einschließen. Die folgende Tabelle sollte hilfreich sein:

  |Element-Konstruktor mit Ausdruck...|wird ausgewertet zu...|
  |:-------|:-------|
  |&lt;e>sum((1,2,3))&lt;/e>|&lt;e>sum((1,2,3))&lt;/e>|
  |&lt;e>sum(**{**(1,2,3)**}**)&lt;/e>|&lt;e>sum(1 2 3)&lt;/e>|
  |&lt;e>**{**sum((1,2,3))**}**&lt;/e>|&lt;e>6&lt;/e>|
9. `FLWOR` (**F**or **L**et **W**here **O**rder **R**eturn) spielt eine wichtige Rolle in XQeury und viele Probleme mögen auch auftauchen wegen Missverständnissen. Folgendermaßen werden manche davon erklärt:
   - Die `for` Klausel bindet jeweils einmal den Wert aus einer Liste mit einem "Variable", während die `let` Klausel nur einmal den rechtsseitigen Wert mit dem linksseitigen "Variable" bindet, egal ob der rechtsseitige Wert eine Liste ist oder nicht. Zum Beispiel nach dem Aufruf `let $i := (2,3,1)` wird der "Variable" `i` mit der Liste `(2,3,1)` gebunden, aber nach dem Aufruf `for $i in (2,3,1)` wird der "Variable" `i` während der Schleife dreimal gebunden, jeweils mit `2`, `3` und `1`.
   - Die `order by` Klausel wird **KEINE** Sortierung bei jeder Iteration von `FLWOR` ausführen. Sie wird jeweils nur den Ausdruck auswerten und eine parallele Liste von Ordnungswerten erzeugen, wonach die Ergebnisliste am Ende der Schleife einmal sortiert wird.
   - Die `return` Klausel ist in XQuery die letzte Klausel von `FLWOR`, und der Aufruf von ihr wird die Schleife nicht abbrechen, sondern nur der zurückgegebene Wert am Ende der Ergebnisliste angehängt.

   Zum Beispiel werden die folgenden Codes ausgewertet zu `4 -4 -2 2 -8 8`, denn die Ordnungsliste erzeugt von `order by` ist `(3, 1, 2)`, und deshalb werden die ersten zwei Ergebnisse `(-8, 8)` nach der Sortierung am Ende der Schleife zum Platz `3` gemapped usw.:
   ```bash
   for $a in (8, -4, 2)
   let $b := ($a * -1, $a)
   order by $a
   return $b
   ```
10. Um Elemente in einer gewissen Reihenfolge zu konstruieren braucht man eine `for` Schleife, denn die Reihenfolge würde ansonsten nicht mehr gewährleistet. Siehe das folgende Beispiel:

  ```bash
  for $a in doc("doc.txt")//p
  return <p>{$a/span/node()}</p>
  ```
11. Verwirrend wäre auch die Nutzung von `true` und `false`, die nicht mehr direkt nutzbar sind, denn in XQuery sind sie **KEINE** Boolean Konstanten, sondern "Namensteste". Die Boolean Werte kann man wie folgendermaßen kriegen:
  - *entweder* mittels der eingebauten Funktionen `true()` und `false()`
  - *oder* mittels dem Boolean Konstruktor `xs:boolean("true")` und `xs:boolean("false")`


## Referenzen
### Achsenbezeichner
|Achsenbezeichner|bezieht sich auf die Achse, die enthält...|
|:-------|:-------|
|`ancestor::`|alle Vorfahren des Kontextknotens (Eltern, Großeltern usw.).|
|`ancestor-or-self::`|alle Vorfahren des Kontextknotens und selbst.|
|`attribute::`|alle Attribute des Kontextknotens.|
|`child::`|alle Kindknoten des Kontextknotens.|
|`descendant::`|alle Nachkommen des Kontextknotens (Kinder, Enkel usw.).|
|`descendant-or-self::`|alle Nachkommen des Kontextknotens und selbst.|
|`following::`|alle Knoten im Baum, die dem Kontextknoten im Dokument folgen, ausschließlich allen Nachkommen des Kontextknotens.|
|`following-sibling::`|alle Kinder des Elternknotens des Kontextknotens, die dem Kontextknoten im Dokument folgen.|
|`parent::`|den Elternknoten des Kontextknotens.|
|`preceding::`|alle Knoten im Baum, die dem Kontextknoten im Dokument vorausgehen, ausschließlich allen Vorfahren des Kontextknotens.|
|`preceding-sibling::`|alle Kinder des Elternknotens des Kontextknotens, die dem Kontextknoten im Dokument vorausgehen.|
|`self::`|den Kontextknoten selbst.|


### Nodeteste
|Node Test|passt zu allen...|
|:-------|:-------|
|`node()`|Knoten aller Arten.|
|`text()`|Textknoten.|
|`comment()`|Kommentarknoten.|
|`element()`|Elementknoten (genau wie der Stern`:*`).|
|`element(name)`|Elementknoten namens `name`.|
|`attribute()`|Attributknoten.|
|`attribute(name)`|Attributknoten namens `name`.|
|`processing-instruction()`|Verarbeitungshinweise.|
|`processing-instruction(name)`|Verarbeitungshinweise namens `name`.|
|`document-node()`|Dokumentknoten (es gibt nur einen).|
|`document-node(element(name))`|Dokumentknoten mit Dokumentelement namens `name`.|


### Kurze Formen
|Kurzschrift-Syntax|erkürzt für...|passt zu allen...|
|:-------|:-------|:-------|
|`name`|`child::element(name)`|Kinderknoten, die Elemente namens `name` sind.|
|`*`|`child::element()`|Kinderknoten, die Elemente sind.|
|`..`|`parent::node()`|Elternknoten (es gibt nur einen).|
|`@*`|`attribute::attribute()`|Attributknoten.|
|`@name`|`attribute::attribute(name)`|Attributknoten namens `name`.|
|`//`|`descendant-or-self::node()`|Nachkommen des Kontextknotens (wenn genutzt anstatt von `/`).|
